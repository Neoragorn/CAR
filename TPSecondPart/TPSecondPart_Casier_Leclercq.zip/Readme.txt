Casier Sofian
Leclercq Vincent

TP5 CAR Second part

Le .zip contient 2 programmes, le client et le serveur.
Le serveur doit être lancé avant le client pour que le programme fonctionne.

Pour lancer le programme, il suffit de se placer dans le dossier racine de chaque projet a l'aide de 2 terminaux et de taper les commandes :

java -jar dist/TP_SecondPart_Server.jar 
java -jar dist/TP_SecondPart_Client.jar 

L'interface devrait alors s'afficher pour s'inscrire ou se connecter.

Nous avons eu de multiples problèmes pour adapter le projet de COO en Java RMI, notamment sur les proxy ainsi que sur l'organisation des fichiers client/serveur/interface.
Nous avons été obligés de copier de nombreux fichiers entre les différents programmes pour pouvoir faire fonctionner le projet.
L'organisation n'est donc sans doute pas la meilleure vu que le projet n'était pas conçu à la base pour du java RMI.



