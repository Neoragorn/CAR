Casier Sofian
Leclercq Vincent

TP4 CAR

Le .zip contient 2 programmes, le client et le serveur. (+ un projet supplementaire qui est l'interface commun)
Le serveur doit être lancé avant le client pour que le programme fonctionne.

Pour lancer le programme, il suffit de se placer dans le dossier racine de chaque projet a l'aide de 2 terminaux et de taper les commandes :

java -jar dist/TP4_CAR_server.jar 
java -jar dist/TP4_CAR_Client.jar 
